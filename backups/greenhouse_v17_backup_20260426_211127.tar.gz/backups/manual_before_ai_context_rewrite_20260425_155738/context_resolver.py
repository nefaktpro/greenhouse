from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List


ROOT = Path("/home/mi/greenhouse_v17")


FILE_DESCRIPTIONS = {
    "data/registry/devices.csv": {
        "title": "Устройства",
        "purpose": "Главный список устройств и HA entity_id. Source of truth по физическим объектам.",
        "edit": "careful",
    },
    "data/registry/action_map.json": {
        "title": "Action Map",
        "purpose": "Связь action_key → logical_role / operation. Через это работают Control, ASK и AI.",
        "edit": "safe_json",
    },
    "data/registry/device_capabilities.json": {
        "title": "Capabilities",
        "purpose": "Инженерные ограничения устройств: режимы, safety, задержки, verify.",
        "edit": "safe_json",
    },
    "data/registry/scenarios.json": {
        "title": "Scenarios",
        "purpose": "Сценарии как данные, а не Python-код.",
        "edit": "safe_json",
    },
    "data/registry/registry_manifest.json": {
        "title": "Registry Manifest",
        "purpose": "Карта registry-файлов и их роли.",
        "edit": "safe_json",
    },
    "data/registry/nl_map.json": {
        "title": "NL Map",
        "purpose": "Карта живых фраз → action_key для AI Router.",
        "edit": "safe_json",
    },
    "chat/intent_parser.py": {
        "title": "Intent Parser",
        "purpose": "Python-код разбора человеческого текста. Не редактировать из UI.",
        "edit": "critical",
    },
    "ai/router.py": {
        "title": "AI Router",
        "purpose": "Маршрутизация AI-задач: вопрос, observation, команда, память.",
        "edit": "critical",
    },
    "ai/context_builder.py": {
        "title": "Context Builder",
        "purpose": "Собирает минимальный runtime context для AI.",
        "edit": "critical",
    },
    "ai/context_resolver.py": {
        "title": "Context Resolver",
        "purpose": "Контролируемый каталог контекстов для AI.",
        "edit": "critical",
    },
}

ALLOWED_CONTEXTS = [
    {
        "key": "registry",
        "title": "Registry",
        "description": "Канонические устройства, действия, capabilities и scenarios.",
        "files": [
            "data/registry/devices.csv",
            "data/registry/action_map.json",
            "data/registry/device_capabilities.json",
            "data/registry/scenarios.json",
            "data/registry/registry_manifest.json",
            "data/registry/nl_map.json",
        ],
        "access": "metadata_and_safe_preview",
    },
    {
        "key": "runtime",
        "title": "Runtime",
        "description": "Текущий режим, ASK-state и оперативное состояние системы.",
        "files": [
            "system_state.json",
            "ask_state.json",
        ],
        "access": "safe_runtime",
    },
    {
        "key": "chat",
        "title": "Chat / Intent",
        "description": "Natural language вход, intent parser и AI router.",
        "files": [
            "chat/intent_parser.py",
            "chat/chat_router.py",
            "ai/router.py",
            "ai/context_builder.py",
            "ai/context_resolver.py",
        ],
        "access": "metadata_only",
    },
    {
        "key": "memory",
        "title": "Memory",
        "description": "Будущая активная память, observations, summaries, cleanup.",
        "files": [
            "knowledge.json",
            "chat_history.json",
            "decision_log.json",
            "strawberry_log.json",
        ],
        "access": "planned_or_optional",
    },
]


def _safe_path(path: str) -> Path:
    p = (ROOT / path).resolve()
    if not str(p).startswith(str(ROOT.resolve())):
        raise ValueError("path_outside_project")
    return p


def _json_meta(path: Path) -> Dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return {"type": "dict", "size": len(data), "keys": list(data.keys())[:20]}
        if isinstance(data, list):
            return {"type": "list", "size": len(data)}
        return {"type": type(data).__name__}
    except Exception as e:
        return {"type": "json_error", "error": str(e)}


def _file_meta(path_str: str) -> Dict[str, Any]:
    path = _safe_path(path_str)
    desc = FILE_DESCRIPTIONS.get(path_str, {})
    meta = {
        "path": path_str,
        "title": desc.get("title", path_str),
        "purpose": desc.get("purpose", "Описание пока не добавлено."),
        "edit": desc.get("edit", "readonly"),
        "exists": path.exists(),
    }
    if not path.exists():
        return meta

    stat = path.stat()
    meta.update({
        "size_bytes": stat.st_size,
        "suffix": path.suffix,
    })

    if path.suffix == ".json":
        meta["json"] = _json_meta(path)
    elif path.suffix == ".csv":
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
            meta["csv"] = {
                "lines": len(lines),
                "header": lines[0] if lines else "",
            }
        except Exception as e:
            meta["csv"] = {"error": str(e)}
    else:
        meta["preview"] = "metadata_only"

    return meta


def get_context_catalog() -> Dict[str, Any]:
    contexts: List[Dict[str, Any]] = []

    for ctx in ALLOWED_CONTEXTS:
        files = [_file_meta(f) for f in ctx["files"]]
        contexts.append({
            **ctx,
            "files": files,
            "files_total": len(files),
            "files_existing": sum(1 for f in files if f.get("exists")),
        })

    return {
        "ok": True,
        "policy": {
            "ai_direct_file_access": False,
            "ai_direct_ha_access": False,
            "ai_direct_execution": False,
            "resolver_required": True,
        },
        "contexts": contexts,
    }



def read_context_file(path_str: str) -> Dict[str, Any]:
    path = _safe_path(path_str)
    meta = _file_meta(path_str)

    if not path.exists():
        return {"ok": False, "error": "file_not_found", "meta": meta}

    if meta.get("edit") == "readonly" and path.suffix == ".py":
        max_chars = 8000
    else:
        max_chars = 16000

    content = path.read_text(encoding="utf-8", errors="replace")
    return {
        "ok": True,
        "meta": meta,
        "content": content[:max_chars],
        "truncated": len(content) > max_chars,
    }




def save_context_file(path_str: str, content: str) -> Dict[str, Any]:
    from datetime import datetime
    import shutil

    meta = _file_meta(path_str)

    if not meta.get("exists"):
        return {"ok": False, "error": "file_not_found", "meta": meta}

    allowed = {f for ctx in ALLOWED_CONTEXTS for f in ctx["files"]}
    if path_str not in allowed:
        return {"ok": False, "error": "file_not_in_context_catalog", "meta": meta}

    path = _safe_path(path_str)
    edit_mode = meta.get("edit", "critical")

    # JSON валидируем, остальные файлы сохраняем как текст.
    if path.suffix == ".json":
        try:
            parsed = json.loads(content)
        except Exception as e:
            return {"ok": False, "error": "invalid_json", "details": str(e), "meta": meta}
        new_content = json.dumps(parsed, ensure_ascii=False, indent=2) + "\n"
    else:
        new_content = content
        if not new_content.endswith("\n"):
            new_content += "\n"

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = ROOT / "backups" / "ui_edits" / ts
    backup_path = backup_dir / path.relative_to(ROOT)
    backup_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, backup_path)

    path.write_text(new_content, encoding="utf-8")

    return {
        "ok": True,
        "path": path_str,
        "edit": edit_mode,
        "backup": str(backup_path.relative_to(ROOT)),
        "warning": "edited_from_ai_context_ui",
        "meta": _file_meta(path_str),
    }

