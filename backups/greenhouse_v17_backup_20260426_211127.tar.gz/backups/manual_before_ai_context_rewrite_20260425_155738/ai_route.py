from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel

from ai.router import route_ai_message
from ai.context_resolver import get_context_catalog, read_context_file, save_context_file
from chat.chat_router import handle_chat_message

router = APIRouter(tags=["ai-lab"])
templates = Jinja2Templates(directory="interfaces/web_admin/templates")


class AIMessageIn(BaseModel):
    text: str


class ContextFileSaveIn(BaseModel):
    path: str
    content: str


@router.get("/web/ai", response_class=HTMLResponse)
def ai_lab_page(request: Request):
    return templates.TemplateResponse(request, "ai_lab.html", {})


@router.post("/api/ai/message")
def ai_message(payload: AIMessageIn):
    # AI Lab preview only.
    # Важно: здесь НЕ вызываем handle_chat_message(),
    # потому что chat_router теперь может создавать ASK / выполнять action.
    ai_result = route_ai_message(payload.text)

    return {
        "ok": True,
        "input": payload.text,
        "ai_router": ai_result,
        "chat_response": {
            "preview_only": True,
            "note": "AI Lab does not create ASK until /api/ai/create-ask is called."
        },
    }


from greenhouse_v17.services.webadmin_execution_service import create_pending_ask, load_ask_state

@router.post("/api/ai/create-ask")
def create_ask_via_actions(payload: AIMessageIn):
    ai_result = route_ai_message(payload.text)
    proposed = ai_result.get("proposed_action")

    if not proposed:
        return {"ok": False, "error": "no_proposed_action"}

    action_key = proposed.get("action_key")
    if not action_key:
        return {"ok": False, "error": "no_action_key"}

    current = load_ask_state()
    if current.get("has_pending"):
        return {
            "ok": False,
            "error": "pending_ask_exists",
            "message": "Сначала подтвердите или отмените текущее ASK-действие.",
            "pending": current,
        }

    state = create_pending_ask(
        action_key=action_key,
        title=f"AI: {payload.text}",
        source="web_admin",
    )

    return {"ok": True, "pending": state}


@router.get("/web/ai/context", response_class=HTMLResponse)
def ai_context_page(request: Request):
    return templates.TemplateResponse(request, "ai_context.html", {})


@router.get("/api/ai/context/catalog")
def ai_context_catalog():
    return get_context_catalog()


@router.get("/api/ai/context/file")
def ai_context_file(path: str):
    return read_context_file(path)


@router.post("/api/ai/context/file/save")
def ai_context_file_save(payload: ContextFileSaveIn):
    return save_context_file(payload.path, payload.content)
