# GREENHOUSE v17

## Main principle

Interfaces do not contain business logic.
Devices, action mapping, capabilities and scenarios are stored in registry/data layer.

## Canonical files

- `data/registry/devices.csv`
- `data/registry/action_map.json`
- `data/registry/device_capabilities.json`
- `data/registry/scenarios.json`
- `data/registry/registry_manifest.json`

## Runtime (not committed)

- `data/runtime/`
- `data/logs/`
- `data/memory/`

## Goal

Telegram, Web Admin and future mobile app should all work through the same Core/Registry/Validation/Execution pipeline.
