from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from chat.intent_parser import ParsedIntent, parse_intent
from ai.router import route_ai_message
from chat.observation_store import add_observation
from greenhouse_v17.services.mode_service import get_mode_flags
from greenhouse_v17.services.webadmin_execution_service import create_pending_ask, execute_action, load_ask_state
from greenhouse_v17.services.decision_logger import log_decision


@dataclass
class ChatResponse:
    reply_text: str
    parsed_intent: ParsedIntent
    response_type: str = "message"
    ask_payload: Optional[Dict[str, Any]] = None
    action_payload: Optional[Dict[str, Any]] = None
    meta: Dict[str, Any] = field(default_factory=dict)


def _build_status_reply() -> str:
    mode = get_mode_flags()
    mode_name = mode.get("title") or mode.get("name", "UNKNOWN")
    execute = "да" if mode.get("execute") else "нет"
    ask = "да" if mode.get("ask") else "нет"
    ai_control = "да" if mode.get("ai_control") else "нет"

    return (
        "🫧 Базовый чат-статус теплицы\n\n"
        f"Текущий режим: {mode_name}\n"
        f"Выполнение действий: {execute}\n"
        f"ASK-подтверждение: {ask}\n"
        f"AI-управление: {ai_control}\n\n"
        "Это первая версия чат-слоя. "
        "Дальше сюда подключим реальный status/AI/context."
    )


def _build_why_reply() -> str:
    return (
        "🤔 Пока я умею распознавать вопрос формата «почему», "
        "но ещё не подключён к explainability-слою.\n\n"
        "Следующий этап — связать чат с decision log, AI summary и текущим snapshot."
    )


def _build_memory_save_reply(text: str) -> str:
    cleaned = text.strip() or "пустая заметка"
    return (
        "🧠 Команда памяти распознана.\n\n"
        f"Что нужно запомнить: {cleaned}\n\n"
        "Пока это ещё не записывается в knowledge.json через chat-layer, "
        "но распознавание уже работает."
    )


def _build_memory_forget_reply(text: str) -> str:
    cleaned = text.strip() or "пустой запрос"
    return (
        "🧹 Команда забывания распознана.\n\n"
        f"Что нужно забыть: {cleaned}\n\n"
        "На следующем шаге подключим реальную работу с памятью."
    )


def _build_device_action_reply(parsed: ParsedIntent) -> ChatResponse:
    mode = get_mode_flags()
    mode_name = mode.get("title") or mode.get("name", "UNKNOWN")
    target = parsed.target or "неизвестная цель"
    action = parsed.action or "unknown"

    human_target_map = {
        "fan_top": "верхний вентилятор",
        "fan_low": "нижний вентилятор",
        "all_fans": "все вентиляторы",
    }

    human_action_map = {
        "turn_on": "включить",
        "turn_off": "выключить",
    }

    action_key_map = {
        ("turn_on", "fan_top"): "fan_top_on",
        ("turn_off", "fan_top"): "fan_top_off",
        ("turn_on", "fan_low"): "fan_low_on",
        ("turn_off", "fan_low"): "fan_low_off",
    }

    action_key = action_key_map.get((action, target))

    human_target = human_target_map.get(target, target)
    human_action = human_action_map.get(action, action)

    reply = (
        "🎛 Команда управления распознана.\n\n"
        f"Действие: {human_action}\n"
        f"Цель: {human_target}\n"
        f"Режим системы: {mode_name}\n\n"
    )

    if not action_key:
        reply += "Для этой команды action_key пока не настроен."
        return ChatResponse(
            reply_text=reply,
            parsed_intent=parsed,
            response_type="message",
            meta={"mode": mode_name, "unsupported_mapping": True},
        )

    if mode_name == "TEST":
        reply += "Сейчас TEST-режим: я не выполняю действие, только показываю, что сделал бы."
        return ChatResponse(
            reply_text=reply,
            parsed_intent=parsed,
            response_type="message",
            action_payload={
                "action_key": action_key,
                "dry_run": True,
            },
            meta={"mode": mode_name},
        )

    if mode.get("ask"):
        current = load_ask_state()
        if current.get("has_pending"):
            reply += "Уже есть действие, ожидающее подтверждения. Сначала подтверди или отмени его в ASK."
            return ChatResponse(
                reply_text=reply,
                parsed_intent=parsed,
                response_type="ask_blocked",
                ask_payload=current,
                meta={"mode": mode_name, "error": "pending_ask_exists"},
            )

        pending = create_pending_ask(
            action_key=action_key,
            title=f"Chat: {human_action} {human_target}",
            source="chat",
        )
        log_decision(
            mode=mode_name,
            source="chat",
            event="ask_created",
            action_key=action_key,
            ok=True,
            result="pending",
            details={"text": text, "pending": pending},
        )
        reply += "Создал ASK-подтверждение. Открой раздел ASK и подтверди или отмени."
        return ChatResponse(
            reply_text=reply,
            parsed_intent=parsed,
            response_type="ask_created",
            ask_payload=pending,
            meta={"mode": mode_name},
        )

    reply += "Выполняю действие через общий execution pipeline."
    result = execute_action(action_key=action_key, dry_run=False, source="chat")
    log_decision(
        mode=mode_name,
        source="chat",
        event="action_executed",
        action_key=action_key,
        ok=bool(result.get("ok")),
        result=result.get("status") or result.get("message"),
        details={"text": text, "execution_result": result},
    )
    return ChatResponse(
        reply_text=reply,
        parsed_intent=parsed,
        response_type="action_executed",
        action_payload=result,
        meta={"mode": mode_name, "ok": bool(result.get("ok"))},
    )


def handle_chat_message(text: str) -> ChatResponse:
    # === AI ROUTER DEBUG HOOK ===
    try:
        ai_debug = route_ai_message(text)
        print("\n=== AI ROUTER DEBUG ===")
        print(ai_debug)
    except Exception as e:
        print("AI ROUTER ERROR:", e)

    parsed = parse_intent(text)

    if parsed.intent_type == "empty":
        return ChatResponse(
            reply_text="Сообщение пустое. Напиши вопрос, команду или наблюдение.",
            parsed_intent=parsed,
        )

    if parsed.intent_type == "status_question":
        return ChatResponse(
            reply_text=_build_status_reply(),
            parsed_intent=parsed,
            response_type="status",
        )

    if parsed.intent_type == "why_question":
        return ChatResponse(
            reply_text=_build_why_reply(),
            parsed_intent=parsed,
            response_type="explain_stub",
        )

    if parsed.intent_type == "memory_save":
        return ChatResponse(
            reply_text=_build_memory_save_reply(parsed.payload.get("text", "")),
            parsed_intent=parsed,
            response_type="memory_stub",
        )

    if parsed.intent_type == "memory_forget":
        return ChatResponse(
            reply_text=_build_memory_forget_reply(parsed.payload.get("text", "")),
            parsed_intent=parsed,
            response_type="memory_stub",
        )

    if parsed.intent_type == "observation":
        saved = add_observation(
            text=parsed.payload.get("text", text),
            source="user",
            category="chat_observation",
            meta={"tags": parsed.tags},
        )
        return ChatResponse(
            reply_text=(
                "👀 Наблюдение сохранено.\n\n"
                f"Текст: {saved['text']}\n"
                f"Время: {saved['timestamp']}"
            ),
            parsed_intent=parsed,
            response_type="observation_saved",
            meta={"saved": saved},
        )

    if parsed.intent_type == "device_action":
        return _build_device_action_reply(parsed)

    if parsed.intent_type == "generic_question":
        return ChatResponse(
            reply_text=(
                "❓ Я понял, что это вопрос, но пока не смог точно определить тип.\n\n"
                "Попробуй переформулировать, например:\n"
                "• что с теплицей?\n"
                "• почему низ сухой?\n"
                "• включи верхний вентилятор"
            ),
            parsed_intent=parsed,
            response_type="generic_question",
        )

    return ChatResponse(
        reply_text=(
            "💬 Сообщение получено, но пока не классифицировано точно.\n\n"
            "На этом этапе чат уже умеет различать часть команд, наблюдений и вопросов."
        ),
        parsed_intent=parsed,
        response_type="generic_message",
    )
