from __future__ import annotations

from fastapi import APIRouter
from greenhouse_v17.services.decision_logger import log_decision

from greenhouse_v17.services.webadmin_execution_service import (
    load_ask_state,
    confirm_pending_ask,
    cancel_pending_ask,
)

router = APIRouter(prefix="/api/ask", tags=["ask"])


@router.get("/current")
def ask_current():
    state = load_ask_state()
    if not state or not state.get("has_pending"):
        return {"ok": True, "has_pending": False, "item": None}
    return {"ok": True, "has_pending": True, "item": state}


@router.post("/confirm")
def ask_confirm():
    result = confirm_pending_ask()

    try:
        # вытаскиваем action_key из глубины результата
        action_key = None
        try:
            action_key = result.get("result", {}).get("action_key")
        except:
            pass

        log_decision(
            mode="ASK",
            source="web_admin",
            event="ask_confirmed",
            action_key=action_key,
            ok=True,
            result="confirmed",
            details={"result": result}
        )
    except Exception as e:
        print("LOG ERROR confirm:", e)

    return result


@router.post("/cancel")
def ask_cancel():
    result = cancel_pending_ask()

    try:
        # cancel не возвращает action_key — берем из текущего pending до сброса
        action_key = None
        try:
            state = load_ask_state()
            if state and state.get("action_key"):
                action_key = state.get("action_key")
        except:
            pass

        log_decision(
            mode="ASK",
            source="web_admin",
            event="ask_cancelled",
            action_key=action_key,
            ok=True,
            result="cancelled",
            details={"result": result}
        )
    except Exception as e:
        print("LOG ERROR cancel:", e)

    return result
